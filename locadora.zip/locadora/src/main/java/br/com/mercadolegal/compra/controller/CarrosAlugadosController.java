package br.com.mercadolegal.compra.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.mercadolegal.compra.entidade.CarrosAlugados;
import br.com.mercadolegal.compra.pojo.CarrosAlugadosPojo;
import br.com.mercadolegal.compra.repository.CarrosAlugadosRepository;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/carros-alugados")
public class CarrosAlugadosController {
	private final CarrosAlugadosRepository carrosalugadosRepository;

	public CarrosAlugadosController(CarrosAlugadosRepository carrosalugadosRepository) {
		this.carrosalugadosRepository = carrosalugadosRepository;
	}
	
	@PostMapping
	@Operation(summary = "Inserir carros alugados", description = "Insere os status dos carros.")
	public CarrosAlugadosPojo create(@RequestBody CarrosAlugadosPojo carrosalugadosPojo) {
		return new CarrosAlugadosPojo(carrosalugadosRepository.save(carrosalugadosPojo.toEntity()));
	}
	
	@PutMapping
	@Operation(summary = "Alterar carros alugados", description = "Altera o status dos carros.")
	public CarrosAlugadosPojo update(@RequestBody CarrosAlugadosPojo carrosalugadosPojo) {
		return new CarrosAlugadosPojo(carrosalugadosRepository.save(carrosalugadosPojo.toEntity()));
	}
	
	@DeleteMapping
	@Operation(summary = "Deletar carros alugados", description = "Deleta todos os carros que estão alugados.")
	public void delete(@PathVariable Long id) {
		carrosalugadosRepository.deleteById(id);
	}
	
	@GetMapping("/{id}")
	@Operation(summary = "Recuperar carros alugados por ID", description = "Recupera todos os carros alugados cadastrados por ID.")
	public CarrosAlugadosPojo get(@PathVariable Long id) {
	Optional<CarrosAlugados> carrosalugadosOptional = carrosalugadosRepository.findById(id);
	if(carrosalugadosOptional.isPresent()) {
		return new CarrosAlugadosPojo(carrosalugadosOptional.get());
	}
	return new CarrosAlugadosPojo();
	}
	
	@GetMapping
	@Operation(summary = "Recuperar carros alugados", description = "Recupera todos os carros alugados cadastrados.")
	public List<CarrosAlugadosPojo> get(){
		return carrosalugadosRepository.findAll().stream().map(CarrosAlugadosPojo::new).collect(Collectors.toList());
	}
}
