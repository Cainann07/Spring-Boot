package br.com.mercadolegal.compra.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import br.com.mercadolegal.compra.entidade.CarrosAlugados;


public class CarrosAlugadosPojo {
	private Long id;
	private String nome;
	private String categoria;
	private Boolean alugado;
	private Integer valor;
	private String marca;
	private String placa;
	private String cor;

	
	public CarrosAlugadosPojo(CarrosAlugados carrosalugados) {
		this.id = carrosalugados.getId();
		this.nome = carrosalugados.getNome();
		this.alugado = carrosalugados.getAlugado();
		this.categoria = carrosalugados.getCategoria();
		this.valor = carrosalugados.getValor();
		this.marca = carrosalugados.getMarca();
		this.placa = carrosalugados.getPlaca();
		this.cor = carrosalugados.getCor();

	}
	public CarrosAlugadosPojo() {
		
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public Boolean getAlugado() {
		return alugado;
	}
	public void setAlugado(Boolean alugado) {
		this.alugado = alugado;
	}
	public Integer getValor() {
		return valor;
	}
	public void setValor(Integer valor) {
		this.valor = valor;
	}
	
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	@JsonIgnore
	public CarrosAlugados toEntity() {
		CarrosAlugados carroalugado = new CarrosAlugados();
		carroalugado.setId(id);
		carroalugado.setNome(nome);
		carroalugado.setCategoria(categoria);
		carroalugado.setAlugado(alugado);
		carroalugado.setValor(valor);
		carroalugado.setMarca(marca);
		carroalugado.setPlaca(placa);
		carroalugado.setCor(cor);
		return carroalugado;

	}
	

}
