package br.com.mercadolegal.compra.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.com.mercadolegal.compra.entidade.Carro;
import br.com.mercadolegal.compra.exception.NegocioException;
import br.com.mercadolegal.compra.pojo.CarroPojo;
import br.com.mercadolegal.compra.repository.CarroRepository;

@Service
public class CarroService {
	
	private final CarroRepository carroRepository;
	
	public CarroService (CarroRepository carroRepository) {
		this.carroRepository = carroRepository;
	}
	
	public CarroPojo salvar(Carro carro) {
		validarCarros(carro);
		return new CarroPojo(carroRepository.save(carro));
	}
	
	private void validarCarros(Carro carro) {
		if (carro.getNome() == null) {
			throw new NegocioException("Nome do carro é obrigatório");
		} else if (carro.getCategoria() == null) {
			throw new NegocioException("A categoria do carro é obrigatória");
		} else if (carro.getValor() == null) {
			throw new NegocioException("O valor do carro é obrigatório");
		} else if (carro.getValor() == 0) {
			throw new NegocioException("O valor do carro não pode ser zero");
		}
		
		List<Carro> carroBd = carroRepository.findByNome(carro.getNome());
		if (carroBd != null && !carroBd.isEmpty()) {
			throw new NegocioException("Carro já cadastrado");
		}
	}
	
	public List<CarroPojo> recuperarCarros(){
		List<Carro> carroList = carroRepository.findAll();
		List<CarroPojo> carroPojoList = new ArrayList<>();
		for(Carro carro: carroList) {
			carroPojoList.add(new CarroPojo(carro));
		}
		return carroPojoList;
	}
	
	public CarroPojo recuperarCarro(Long id) {
		Optional<Carro> carroOptional = carroRepository.findById(id);
		if(carroOptional.isPresent()) {
			return new CarroPojo(carroOptional.get());
		}
		return null;
	}
	
	public void deletarCarro(Long id) {
		carroRepository.deleteById(id);
	}
}
