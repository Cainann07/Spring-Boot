package br.com.mercadolegal.compra.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.mercadolegal.compra.entidade.Aluguel;

public interface AluguelRepository extends JpaRepository<Aluguel, Long>{
	
	
}
