package br.com.mercadolegal.compra.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.mercadolegal.compra.entidade.Cliente;
import br.com.mercadolegal.compra.exception.NegocioException;
import br.com.mercadolegal.compra.pojo.ClientePojo;
import br.com.mercadolegal.compra.repository.ClienteRepository;
import br.com.mercadolegal.compra.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

	private final ClienteService clienteService;

	// Injeção de dependencia
	public ClienteController(ClienteService clienteService) {
		this.clienteService = clienteService;
	}

	@GetMapping
	@Operation(summary = "Recupera clientes", description = "Recupera todos os clientes cadastrados.")
	public ResponseEntity<List<ClientePojo>> getAll() {
		return ResponseEntity.ok(clienteService.recuperarClientes());
	}

	// isso para aparecer o 1 no insomnia no link
	// pega oq tá no insomnia e joga no identificador
	@GetMapping(path = "/{id}")
	@Operation(summary = "Recuperar clientes por ID", description = "Recupera o cliente cadastrado por ID.")
	public ResponseEntity<ClientePojo> get(@PathVariable Long id) {
		ClientePojo clientePojo = clienteService.recuperarCliente(id);
		if (clientePojo == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(clientePojo);
	}


	@PostMapping
	@Operation(summary = "Inserir clientes", description = "Cadastra novos clientes")
	public ResponseEntity<?> create(@RequestBody ClientePojo clientePojo) {
		try {
			return new ResponseEntity<ClientePojo>(clienteService.salvar(clientePojo.toEntity()), HttpStatus.CREATED);
		} catch (NegocioException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.PRECONDITION_FAILED);
		}
	}

	@PutMapping
	@Operation(summary = "Alterar Clientes", description = "Altera o cadastro dos clientes")
	public ResponseEntity<?> update(@RequestBody ClientePojo clientePojo) {
		try {
			return ResponseEntity.ok(clienteService.salvar(clientePojo.toEntity()));
		} catch (NegocioException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.PRECONDITION_FAILED);
		}
	}

	@DeleteMapping(path = "/{id}")
	@Operation(summary = "Deletar clientes", description = "Deleta os clientes cadastrados")
	public ResponseEntity<?> delete(@PathVariable Long id) {
		clienteService.deletarCliente(id);
		return ResponseEntity.ok().build();
	}

	
}