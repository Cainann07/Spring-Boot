package br.com.mercadolegal.compra.pojo;

import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.mercadolegal.compra.entidade.Pagamento;
import br.com.mercadolegal.compra.entidade.Carro;

public class PagamentoPojo {

	private Long id;
	private ClientePojo cliente;
	private List<CarroPojo> carros;
	private String valor_pagamento;
	private Boolean pago;

	public PagamentoPojo() {

	}

	public PagamentoPojo(Pagamento pagamento) {
		this.id = pagamento.getId();
		this.cliente = new ClientePojo(pagamento.getCliente());
		this.carros = pagamento.getCarros().stream().map(CarroPojo::new).collect(Collectors.toList());// Converte uma lista de produtos em uma lista de Pojo.
		this.valor_pagamento = pagamento.getValor_pagamento();
		this.pago = pagamento.getPago();

	}
	@JsonIgnore
	public Pagamento toEntity() {
		Pagamento pagamento = new Pagamento();
		pagamento.setId(id);
		pagamento.setCliente(cliente.toEntity());
		pagamento.setCarros(carros.stream().map(CarroPojo::toEntity).collect(Collectors.toList())); // Transforma uma lista de entidades em uma lista de Pojo.
		pagamento.setValor_pagamento(valor_pagamento);
		pagamento.setPago(pago);


		return pagamento;
	}
	
	

	public Boolean getPago() {
		return pago;
	}

	public void setPago(Boolean pago) {
		this.pago = pago;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ClientePojo getCliente() {
		return cliente;
	}

	public void setCliente(ClientePojo cliente) {
		this.cliente = cliente;
	}

	public List<CarroPojo> getCarros() {
		return carros;
	}

	public void setCarros(List<CarroPojo> carros) {
		this.carros = carros;
	}

	public String getValor_pagamento() {
		return valor_pagamento;
	}

	public void setValor_pagamento(String valor_pagamento) {
		this.valor_pagamento = valor_pagamento;
	}


	
}
