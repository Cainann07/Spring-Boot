package br.com.mercadolegal.compra.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import br.com.mercadolegal.compra.entidade.Carro;

@Repository
public interface CarroRepository extends JpaRepository<Carro, Long> {
	public List<Carro> findByNome(String nome);


}
