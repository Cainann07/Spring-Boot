package br.com.mercadolegal.compra.pojo;

import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.mercadolegal.compra.entidade.Aluguel;
import br.com.mercadolegal.compra.entidade.Carro;

public class AluguelPojo {

	private Long id;
	private ClientePojo cliente;
	private List<CarroPojo> carros;

	public AluguelPojo() {

	}

	public AluguelPojo(Aluguel aluguel) {
		this.id = aluguel.getId();
		this.cliente = new ClientePojo(aluguel.getCliente());
		this.carros = aluguel.getCarros().stream().map(CarroPojo::new).collect(Collectors.toList());// Converte uma lista de produtos em uma lista de Pojo.
	}
	@JsonIgnore
	public Aluguel toEntity() {
		Aluguel aluguel = new Aluguel();
		aluguel.setId(id);
		aluguel.setCliente(cliente.toEntity());
		aluguel.setCarros(carros.stream().map(CarroPojo::toEntity).collect(Collectors.toList())); // Transforma uma lista de entidades em uma lista de Pojo.
		return aluguel;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ClientePojo getCliente() {
		return cliente;
	}

	public void setCliente(ClientePojo cliente) {
		this.cliente = cliente;
	}

	public List<CarroPojo> getCarros() {
		return carros;
	}

	public void setCarros(List<CarroPojo> carros) {
		this.carros = carros;
	}

}
