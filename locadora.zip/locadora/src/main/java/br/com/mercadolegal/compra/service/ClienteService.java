package br.com.mercadolegal.compra.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.com.mercadolegal.compra.entidade.Cliente;
import br.com.mercadolegal.compra.exception.NegocioException;
import br.com.mercadolegal.compra.pojo.ClientePojo;
import br.com.mercadolegal.compra.repository.ClienteRepository;

@Service
public class ClienteService {
	
	private final ClienteRepository clienteRepository;
	
	public ClienteService (ClienteRepository clienteRepository) {
		this.clienteRepository = clienteRepository;
	}
	
	public ClientePojo salvar(Cliente cliente) {
		validarClientes(cliente);
		return new ClientePojo(clienteRepository.save(cliente));
	}
	
	private void validarClientes(Cliente cliente) {
		if (cliente.getNome() == null) {
			throw new NegocioException("Nome do cliente é obrigatório.");
		} else if (cliente.getCpf() == null) {
			throw new NegocioException("O CPF do cliente é obrigatório.");
		}
		
		List<Cliente> clienteBd = clienteRepository.findByCpf(cliente.getCpf());
		if (clienteBd != null && !clienteBd.isEmpty()) {
			throw new NegocioException("Cliente já cadastrado!");
		}
	}
	
	public List<ClientePojo> recuperarClientes(){
		List<Cliente> clienteList = clienteRepository.findAll();
		List<ClientePojo> clientePojoList = new ArrayList<>();
		for(Cliente cliente: clienteList) {
			clientePojoList.add(new ClientePojo(cliente));
		}
		return clientePojoList;
	}
	
	public ClientePojo recuperarCliente(Long id) {
		Optional<Cliente> clienteOptional = clienteRepository.findById(id);
		if(clienteOptional.isPresent()) {
			return new ClientePojo(clienteOptional.get());
		}
		return null;
	}
	
	public void deletarCliente(Long id) {
		clienteRepository.deleteById(id);
	}
}
