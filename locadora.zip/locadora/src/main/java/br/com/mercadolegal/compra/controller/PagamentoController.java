package br.com.mercadolegal.compra.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.mercadolegal.compra.entidade.Pagamento;
import br.com.mercadolegal.compra.pojo.PagamentoPojo;
import br.com.mercadolegal.compra.repository.PagamentoRepository;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/pagamentos")
public class PagamentoController {
	private final PagamentoRepository pagamentoRepository;

	public PagamentoController(PagamentoRepository pagamentoRepository) {
		this.pagamentoRepository = pagamentoRepository;
	}
	
	@PostMapping
	@Operation(summary = "Recuperar pagamentos", description = "Recupera todos os pagamentos cadastrados.")
	public PagamentoPojo create(@RequestBody PagamentoPojo pagamentoPojo) {
		return new PagamentoPojo(pagamentoRepository.save(pagamentoPojo.toEntity()));
	}
	
	@PutMapping
	@Operation(summary = "Alterar pagamento", description = "Altera o pagamento.")
	public PagamentoPojo update(@RequestBody PagamentoPojo pagamentoPojo) {
		return new PagamentoPojo(pagamentoRepository.save(pagamentoPojo.toEntity()));
	}
	
	@DeleteMapping
	@Operation(summary = "Deletar pagamento", description = "Deleta todos os pagamentos cadastrados.")
	public void delete(@PathVariable Long id) {
		pagamentoRepository.deleteById(id);
	}
	
	@GetMapping("/{id}")
	@Operation(summary = "Recuperar pagamentos por ID", description = "Recupera o pagamento por ID.")
	public PagamentoPojo get(@PathVariable Long id) {
	Optional<Pagamento> pagamentoOptional = pagamentoRepository.findById(id);
	if(pagamentoOptional.isPresent()) {
		return new PagamentoPojo(pagamentoOptional.get());
	}
	return new PagamentoPojo();
	}
	
	@GetMapping
	@Operation(summary = "Recuperar pagamentos", description = "Recupera todos os pagamentos cadastrados.")
	public List<PagamentoPojo> get(){
		return pagamentoRepository.findAll().stream().map(PagamentoPojo::new).collect(Collectors.toList());
	}
}
