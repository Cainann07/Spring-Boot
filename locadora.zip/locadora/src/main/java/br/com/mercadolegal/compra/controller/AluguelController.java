package br.com.mercadolegal.compra.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.mercadolegal.compra.entidade.Aluguel;
import br.com.mercadolegal.compra.pojo.AluguelPojo;
import br.com.mercadolegal.compra.repository.AluguelRepository;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/aluguel")
public class AluguelController {
	private final AluguelRepository aluguelRepository;

	public AluguelController(AluguelRepository aluguelRepository) {
		this.aluguelRepository = aluguelRepository;
	}
	
	@PostMapping
	@Operation(summary = "Cadastrar Aluguel", description = "Cadastra novos aluguéis.")
	public AluguelPojo create(@RequestBody AluguelPojo aluguelPojo) {
		return new AluguelPojo(aluguelRepository.save(aluguelPojo.toEntity()));
	}
	
	@PutMapping
	@Operation(summary = "Alterar Aluguel", description = "Altera os aluguéis cadastrados.")
	public AluguelPojo update(@RequestBody AluguelPojo aluguelPojo) {
		return new AluguelPojo(aluguelRepository.save(aluguelPojo.toEntity()));
	} 
	
	@DeleteMapping
	@Operation(summary = "Deletar Aluguéis", description = "Deleta todos alguéis cadastrados.")
	public void delete(@PathVariable Long id) {
		aluguelRepository.deleteById(id);
	}
	
	@GetMapping("/{id}")
	@Operation(summary = "Recuperar aluguéis por ID", description = "Recupera os aluguéis cadastrados por ID.")
	public AluguelPojo get(@PathVariable Long id) {
	Optional<Aluguel> aluguelOptional = aluguelRepository.findById(id);
	if(aluguelOptional.isPresent()) {
		return new AluguelPojo(aluguelOptional.get());
	}
	return new AluguelPojo();
	}
	
	@GetMapping
	@Operation(summary = "Recuperar aluguéis", description = "Recupera todos os aluguéis cadastratos")
	public List<AluguelPojo> get(){
		return aluguelRepository.findAll().stream().map(AluguelPojo::new).collect(Collectors.toList());
	}
}
